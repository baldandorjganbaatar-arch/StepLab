package mn.steplab

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var stepDetector: Sensor? = null
    private var stepCounter: Sensor? = null
    private var accelerometer: Sensor? = null

    private var liveSteps by mutableIntStateOf(0)
    private var sensorStatus by mutableStateOf("Мэдрэгч шалгаж байна…")
    private var accelText by mutableStateOf("X: —   Y: —   Z: —")
    private var liveMode by mutableStateOf(false)
    private var counterStart = -1f

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startLiveSensors() else sensorStatus = "Хөдөлгөөн таних зөвшөөрөл олгогдоогүй"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepDetector = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        stepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorStatus = buildString {
            append("Step Detector: "); append(if (stepDetector != null) "байна" else "байхгүй")
            append(" · Step Counter: "); append(if (stepCounter != null) "байна" else "байхгүй")
        }
        setContent { StepLabScreen() }
    }

    private fun startLiveSensors() {
        liveSteps = 0
        counterStart = -1f
        liveMode = true
        stepDetector?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        if (stepDetector == null) {
            stepCounter?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        sensorStatus = if (stepDetector != null || stepCounter != null) "Бодит мэдрэгч ажиллаж байна" else "Алхам мэдрэгч энэ төхөөрөмжид олдсонгүй"
    }

    private fun stopLiveSensors() {
        sensorManager.unregisterListener(this)
        liveMode = false
        sensorStatus = "Бодит мэдрэгч зогссон"
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_STEP_DETECTOR -> liveSteps += 1
            Sensor.TYPE_STEP_COUNTER -> {
                val total = event.values[0]
                if (counterStart < 0f) counterStart = total
                liveSteps = (total - counterStart).toInt().coerceAtLeast(0)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                accelText = "X: %.2f   Y: %.2f   Z: %.2f m/s²".format(event.values[0], event.values[1], event.values[2])
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onPause() {
        super.onPause()
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
    }

    @Composable
    private fun StepLabScreen() {
        var requestedSteps by remember { mutableIntStateOf(1000) }
        var rate by remember { mutableIntStateOf(100) }
        var simulatedSteps by remember { mutableIntStateOf(0) }
        var progress by remember { mutableFloatStateOf(0f) }
        var running by remember { mutableStateOf(false) }
        var resultText by remember { mutableStateOf("Тест эхлээгүй") }
        val scope = rememberCoroutineScope()

        MaterialTheme {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("StepLab", style = MaterialTheme.typography.headlineLarge)
                    Text("Алхам хэмжигчийн туршилтын лаборатори", style = MaterialTheme.typography.bodyMedium)

                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ХИЙМЭЛ АЛХМЫН ТЕСТ", style = MaterialTheme.typography.titleMedium)
                            Text("Тестийн алхам: $requestedSteps")
                            Slider(value = requestedSteps.toFloat(), onValueChange = { requestedSteps = it.toInt() }, valueRange = 100f..5000f, steps = 48)
                            Text("Хурд: $rate алхам/мин")
                            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                                listOf(60, 100, 140).forEachIndexed { index, value ->
                                    SegmentedButton(
                                        selected = rate == value,
                                        onClick = { rate = value },
                                        shape = SegmentedButtonDefaults.itemShape(index, 3)
                                    ) { Text(value.toString()) }
                                }
                            }
                            Text("Хугацаа: ${requestedSteps * 60 / rate} секунд")
                            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                            Text("Алгоритмын илрүүлсэн алхам: $simulatedSteps", style = MaterialTheme.typography.titleLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    enabled = !running,
                                    onClick = {
                                        running = true
                                        simulatedSteps = 0
                                        progress = 0f
                                        resultText = "Хиймэл өгөгдөл үүсгэж байна…"
                                        scope.launch {
                                            val output = withContext(Dispatchers.Default) {
                                                val detector = PeakStepDetector()
                                                val sampleRate = 50
                                                val duration = 60.0 / rate
                                                val count = (requestedSteps * duration * sampleRate).toInt()
                                                var detected = 0
                                                for (i in 0 until count) {
                                                    val t = i.toDouble() / sampleRate
                                                    val phase = 2.0 * PI * t / duration
                                                    val z = 9.81 + 1.8 * sin(phase) + Random.nextDouble(-0.04, 0.04)
                                                    if (detector.addSample(z.toFloat(), (t * 1_000_000_000).toLong())) detected++
                                                }
                                                detected
                                            }
                                            simulatedSteps = output
                                            progress = 1f
                                            resultText = "Дууссан. Зорилтот: $requestedSteps · Илрүүлсэн: $output · Зөрүү: ${output - requestedSteps}"
                                            running = false
                                        }
                                    }
                                ) { Text("Тест эхлүүлэх") }
                                OutlinedButton(enabled = !running, onClick = { simulatedSteps = 0; progress = 0f; resultText = "Тест эхлээгүй" }) { Text("Арилгах") }
                            }
                            Text(resultText, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("БОДИТ УТАСНЫ МЭДРЭГЧ", style = MaterialTheme.typography.titleMedium)
                            Text(sensorStatus, style = MaterialTheme.typography.bodySmall)
                            Text("Бодит алхам: $liveSteps", style = MaterialTheme.typography.headlineMedium)
                            Text("Accelerometer: $accelText", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
                                        permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                                    } else startLiveSensors()
                                }, enabled = !liveMode) { Text("Бодит хэмжилт эхлүүлэх") }
                                OutlinedButton(onClick = { stopLiveSensors() }, enabled = liveMode) { Text("Зогсоох") }
                            }
                        }
                    }
                    Text("Тайлбар: Хиймэл тест нь зөвхөн StepLab аппын алгоритмыг шалгана. Samsung Health болон бусад аппын жинхэнэ мэдрэгчид хуурамч алхам дамжуулахгүй.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

/** Simple rising-threshold detector used only for this demo signal. */
private class PeakStepDetector {
    private var aboveThreshold = false
    private var lastStepNs = Long.MIN_VALUE
    private val threshold = 10.9f
    private val refractoryNs = 300_000_000L

    fun addSample(z: Float, timestampNs: Long): Boolean {
        if (z < threshold) {
            aboveThreshold = false
            return false
        }
        if (!aboveThreshold && timestampNs - lastStepNs >= refractoryNs) {
            aboveThreshold = true
            lastStepNs = timestampNs
            return true
        }
        aboveThreshold = true
        return false
    }
}
