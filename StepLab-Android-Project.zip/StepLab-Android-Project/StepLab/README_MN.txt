StepLab - Android алхам хэмжигчийн тест апп

Энэ бол Android Studio-д нээж APK болгон бүтээх Kotlin + Jetpack Compose төслийн эх код.

Боломжууд:
- 100–5000 алхмын хиймэл Accelerometer тест
- 60 / 100 / 140 алхам/мин хурд сонгох
- Хиймэл Z тэнхлэгийн өгөгдөл үүсгэж энгийн peak detector-оор тоолох
- Утасны бодит Step Detector / Step Counter мэдрэгчийг шалгах
- Бодит Accelerometer-ийн X/Y/Z утгыг харах

APK бүтээх:
1. Компьютерт Android Studio суулгана.
2. Android Studio -> Open -> StepLab хавтсыг сонгоно.
3. Gradle sync дуусахыг хүлээнэ. Android SDK 35 суулгасан байх шаардлагатай.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. app/build/outputs/apk/debug/app-debug.apk файлыг Android утсандаа хуулж суулгана.

Тайлбар:
- Энэ орчинд Android SDK/Gradle build орчин байхгүй тул APK-г эндээс шууд компайлдаж баталгаажуулах боломжгүй. Төслийг Android Studio-д нээж APK болгоно.
- Хиймэл өгөгдөл нь зөвхөн StepLab дотор ажиллана. Бусад аппын системийн мэдрэгчийн оролтыг өөрчлөхгүй.
- Хиймэл дохио нь сургалт/туршилтын хялбарчилсан загвар; бодит алхалтын бүх хэв маягийг төлөөлөхгүй.
